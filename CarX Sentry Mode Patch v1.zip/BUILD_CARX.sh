#!/usr/bin/env bash
set -e

echo "=============================================="
echo "     CarX Sentry Mode - Patch + Debug Build"
echo "=============================================="

if [ ! -f "./gradlew" ]; then
  echo "ERROR: Run this from the root of CarX-Sentry-Mode."
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

python3 "$SCRIPT_DIR/carx_patch.py"
chmod +x ./gradlew

echo
echo "[CarX] Starting Android debug build..."
./gradlew assembleDebug

APK="app/build/outputs/apk/debug/app-debug.apk"
echo
if [ -f "$APK" ]; then
  echo "=============================================="
  echo "BUILD SUCCESS"
  echo "APK: $APK"
  echo "=============================================="
else
  echo "Build command finished but APK was not found at $APK"
  echo "Check Gradle output above."
  exit 2
fi
