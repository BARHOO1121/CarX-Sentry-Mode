CARX SENTRY MODE — أسهل طريقة

1) افتح Codespace الخاص بمستودع:
   BARHOO1121/CarX-Sentry-Mode

2) ارفع الملفين:
   carx_patch.py
   BUILD_CARX.sh
   إلى مجلد داخل المشروع اسمه:
   carx-tools

3) افتح Terminal من جذر المشروع واكتب فقط:

   chmod +x carx-tools/BUILD_CARX.sh
   ./carx-tools/BUILD_CARX.sh

4) إذا ظهر BUILD SUCCESS ستجد APK هنا:

   app/build/outputs/apk/debug/app-debug.apk

هذا الباتش يعمل:
- اسم التطبيق الظاهر: CarX Sentry Mode
- تعريب عربي + إنجليزي للنصوص الأساسية الخاصة بالسنتري
- شكل Dashboard مستقبلي داكن وخفيف
- زر مباشر Disable / Restore للـ BYD Native DVR
- يستخدم API الموجود أصلًا في المشروع لـ com.byd.cdr
- لا يغير package/applicationId في النسخة الأولى حتى لا نكسر الـ daemons والكاميرات
- لا يعبث بمنطق الكاميرات الأساسي
- يحافظ على MIT LICENSE الأصلي
- يعمل نسخة احتياطية في .carx_backup_v1/

هذه V1 آمنة لاختبار البناء والتشغيل أولاً.
بعد نجاحها نكمل V2: الأيقونة، 3D BYD أقوى، تعريب أوسع، وتنظيف الميزات غير الضرورية.
