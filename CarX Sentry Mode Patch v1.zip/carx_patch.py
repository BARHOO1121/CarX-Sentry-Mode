#!/usr/bin/env python3
from pathlib import Path
import json
import shutil
import sys

ROOT = Path.cwd()

FILES = {
    "settings": ROOT / "settings.gradle.kts",
    "strings": ROOT / "app/src/main/res/values/strings.xml",
    "en": ROOT / "app/src/main/assets/web/i18n/en.json",
    "ar": ROOT / "app/src/main/assets/web/i18n/ar.json",
    "shell": ROOT / "app/src/main/assets/web/shared/app-shell.js",
    "index": ROOT / "app/src/main/assets/web/local/index.html",
    "styles": ROOT / "app/src/main/assets/web/shared/styles.css",
}
BACKUP = ROOT / ".carx_backup_v1"

def die(msg):
    print("\n[CarX] ERROR:", msg)
    sys.exit(1)

def require_files():
    missing = [str(p.relative_to(ROOT)) for p in FILES.values() if not p.exists()]
    if missing:
        die("Run this from the repository root. Missing: " + ", ".join(missing))

def backup_file(path: Path):
    rel = path.relative_to(ROOT)
    dest = BACKUP / rel
    if not dest.exists():
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)

def write_text(path: Path, content: str):
    backup_file(path)
    path.write_text(content, encoding="utf-8")
    print("[CarX] updated", path.relative_to(ROOT))

def replace_once(path: Path, old: str, new: str, required=True):
    text = path.read_text(encoding="utf-8")
    if new in text:
        print("[CarX] already patched", path.relative_to(ROOT))
        return
    if old not in text:
        if required:
            die(f"Expected marker not found in {path.relative_to(ROOT)}: {old[:140]}")
        return
    write_text(path, text.replace(old, new, 1))

def patch_json(path: Path, lang: str):
    backup_file(path)
    data = json.loads(path.read_text(encoding="utf-8"))

    app = data.setdefault("app", {})
    app.update({
        "name": "CarX Sentry Mode",
        "tagline": "مركز حراسة ومراقبة BYD" if lang == "ar" else "BYD Sentry Command Center",
    })

    for key, value in list(app.items()):
        if isinstance(value, str):
            value = value.replace("OverDrive", "CarX Sentry Mode")
            value = value.replace("تجاوز القرص", "CarX Sentry Mode")
            value = value.replace("القيادة المفرطة", "CarX Sentry Mode")
            app[key] = value

    nav = data.setdefault("nav", {})
    if lang == "ar":
        nav.update({
            "dashboard": "الرئيسية",
            "live_view": "عرض الكاميرات",
            "events": "الأحداث",
            "surveillance": "وضع الحراسة",
            "recordings": "التسجيلات",
            "recording_settings": "إعدادات التسجيل",
            "performance": "أداء النظام",
            "settings_group": "الإعدادات",
            "overview_group": "الحراسة",
            "brand_home": "CarX Sentry Mode — فتح الرئيسية",
        })
    else:
        nav.update({
            "dashboard": "Home",
            "live_view": "Live Cameras",
            "events": "Events",
            "surveillance": "Sentry Mode",
            "recordings": "Recordings",
            "recording_settings": "Recording Settings",
            "performance": "System Health",
            "settings_group": "Settings",
            "overview_group": "Sentry",
            "brand_home": "CarX Sentry Mode — open Home",
        })

    oem = data.setdefault("oem_dashcam", {})
    if lang == "ar":
        oem.update({
            "title": "كاميرا DVR الأمامية",
            "native_dvr_title": "DVR الأصلي لسيارة BYD (com.byd.cdr)",
            "native_dvr_explainer": "يعطّل تطبيق التسجيل الأصلي عند الحاجة حتى يستخدم CarX الكاميرا بدون تعارض. يمكنك إعادته في أي وقت.",
            "native_dvr_disable": "تعطيل DVR الأصلي",
            "native_dvr_enable": "إعادة تفعيل DVR الأصلي",
            "native_dvr_status_enabled": "الحالة: DVR الأصلي مفعّل",
            "native_dvr_status_disabled": "الحالة: DVR الأصلي معطّل بواسطة CarX",
            "native_dvr_disable_toast": "تم تعطيل DVR الأصلي. أصبحت الكاميرا متاحة لـ CarX.",
            "native_dvr_enable_toast": "تمت إعادة تفعيل DVR الأصلي.",
            "status_running": "التسجيل نشط",
            "status_starting": "جارٍ التشغيل…",
            "status_idle": "جاهز",
            "status_armed": "الحراسة مفعّلة",
            "status_recording": "يسجل الآن",
        })
    else:
        oem.update({
            "title": "Front DVR Camera",
            "native_dvr_title": "BYD Native DVR (com.byd.cdr)",
            "native_dvr_explainer": "Temporarily disable the factory DVR when CarX needs exclusive camera access. You can restore it at any time.",
            "native_dvr_disable": "Disable BYD Native DVR",
            "native_dvr_enable": "Restore BYD Native DVR",
            "native_dvr_status_enabled": "Status: Native DVR enabled",
            "native_dvr_status_disabled": "Status: Native DVR disabled by CarX",
            "native_dvr_disable_toast": "BYD native DVR disabled. CarX can now own the camera.",
            "native_dvr_enable_toast": "BYD native DVR restored.",
        })

    surv = data.setdefault("surveillance", {})
    if lang == "ar":
        surv.update({
            "page_title": "CarX Sentry Mode",
            "mode": "وضع الحراسة",
            "enable": "تفعيل CarX Sentry Mode",
            "enable_desc": "مراقبة كاميرات BYD أثناء الوقوف وتسجيل الأحداث المهمة.",
            "arm_mode": "طريقة التسليح",
            "arm_lock": "عند قفل السيارة",
            "arm_power": "عند إطفاء السيارة",
            "accoff_mode": "وضع المراقبة أثناء الوقوف",
            "accoff_smart": "ذكي",
            "accoff_continuous": "تسجيل مستمر",
            "status_label": "حالة الحراسة",
            "events_today": "أحداث اليوم",
            "low_power_mode": "وضع توفير الطاقة أثناء الوقوف",
        })
    else:
        surv.update({
            "page_title": "CarX Sentry Mode",
            "mode": "Sentry Mode",
            "enable": "Enable CarX Sentry Mode",
            "enable_desc": "Monitor BYD cameras while parked and record important events.",
            "arm_mode": "Arming Method",
            "arm_lock": "When Vehicle Locks",
            "arm_power": "When Vehicle Powers Off",
            "accoff_mode": "Parked Monitoring Mode",
            "accoff_smart": "Smart",
            "accoff_continuous": "Continuous Recording",
            "status_label": "Sentry Status",
            "events_today": "Events Today",
            "low_power_mode": "Low-Power Parked Mode",
        })

    dash = data.setdefault("dashboard", {})
    dash.update({
        "heading": "CarX Sentry Mode",
        "subtitle": "مركز مراقبة وحماية BYD" if lang == "ar" else "BYD sentry, cameras and security at a glance.",
    })

    carx = data.setdefault("carx", {})
    if lang == "ar":
        carx.update({
            "security_core": "CarX Security Core",
            "dvr_card_title": "التحكم بالـ DVR الأصلي",
            "dvr_card_desc": "تحكم مباشر وآمن بتطبيق BYD الأصلي com.byd.cdr.",
            "dvr_checking": "جارٍ فحص حالة DVR…",
            "dvr_enabled": "DVR الأصلي مفعّل",
            "dvr_disabled": "DVR الأصلي معطّل",
            "dvr_not_installed": "DVR الأصلي غير موجود على هذه السيارة",
            "dvr_disable": "تعطيل DVR الأصلي",
            "dvr_restore": "إعادة تفعيل DVR الأصلي",
            "dvr_failed": "تعذر تغيير حالة DVR",
            "open_sentry": "فتح إعدادات الحراسة",
        })
    else:
        carx.update({
            "security_core": "CarX Security Core",
            "dvr_card_title": "Native DVR Control",
            "dvr_card_desc": "Direct, reversible control of BYD's com.byd.cdr factory recorder.",
            "dvr_checking": "Checking native DVR…",
            "dvr_enabled": "Native DVR enabled",
            "dvr_disabled": "Native DVR disabled",
            "dvr_not_installed": "Native DVR is not installed on this vehicle",
            "dvr_disable": "Disable Native DVR",
            "dvr_restore": "Restore Native DVR",
            "dvr_failed": "Could not change DVR state",
            "open_sentry": "Open Sentry Settings",
        })

    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("[CarX] updated", path.relative_to(ROOT))

def create_carx_css():
    path = ROOT / "app/src/main/assets/web/shared/carx-brand.css"
    content = '''/* CarX Sentry Mode visual layer - lightweight, Chrome 58 compatible. */
:root {
    --carx-blue: #5B7CFF;
    --carx-cyan: #27D7FF;
    --carx-violet: #8A63FF;
    --carx-bg: #070A12;
    --carx-glow: rgba(91,124,255,.24);
    --brand-primary: var(--carx-blue);
    --primary: var(--carx-blue);
    --tertiary: var(--carx-cyan);
    --shadow-glow: 0 0 28px var(--carx-glow);
}
:root:not([data-theme="light"]) {
    --bg-base: #070A12;
    --bg-surface: #0D1220;
    --bg-elevated: #12192A;
    --border-subtle: rgba(128,156,255,.12);
    --border-default: rgba(128,156,255,.22);
}
.brand-logo {
    background:
        radial-gradient(circle at 30% 25%, rgba(39,215,255,.28), transparent 44%),
        linear-gradient(145deg, #151D35, #0A0F1E);
    border: 1px solid rgba(112,143,255,.26);
    box-shadow: 0 0 28px rgba(91,124,255,.16), inset 0 1px 0 rgba(255,255,255,.05);
}
.brand-name {
    background: linear-gradient(90deg, #DDE6FF, #78DBFF, #A98BFF);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.nav-link[href="surveillance.html"] {
    border: 1px solid rgba(91,124,255,.18);
    background: linear-gradient(90deg, rgba(91,124,255,.11), rgba(39,215,255,.03));
}
.dashboard-page .dash-hero {
    position: relative;
    border-radius: 24px;
    border-color: rgba(112,143,255,.20);
    background:
        radial-gradient(60% 90% at 72% 45%, rgba(91,124,255,.14), transparent 72%),
        radial-gradient(45% 70% at 30% 20%, rgba(39,215,255,.11), transparent 70%),
        linear-gradient(145deg, #0E1425 0%, #090D18 58%, #070A12 100%);
    box-shadow: 0 22px 70px rgba(0,0,0,.32), inset 0 1px 0 rgba(255,255,255,.04);
}
.dashboard-page .dash-hero::before,
.dashboard-page .dash-hero::after {
    content: "";
    position: absolute;
    pointer-events: none;
    border: 1px solid rgba(91,124,255,.10);
    border-radius: 999px;
}
.dashboard-page .dash-hero::before {
    width: 330px; height: 330px; right: -110px; top: -100px;
}
.dashboard-page .dash-hero::after {
    width: 220px; height: 220px; right: -55px; top: -45px;
    border-color: rgba(39,215,255,.10);
}
.dashboard-page .dash-glance-car {
    position: relative;
    filter: drop-shadow(0 16px 25px rgba(0,0,0,.35));
}
.dashboard-page .dash-glance-car::before,
.dashboard-page .dash-glance-car::after {
    content: "";
    position: absolute;
    left: 50%; top: 50%;
    transform: translate(-50%,-50%);
    border-radius: 50%;
    pointer-events: none;
}
.dashboard-page .dash-glance-car::before {
    width: 230px; height: 230px;
    border: 1px solid rgba(91,124,255,.18);
    box-shadow: 0 0 45px rgba(91,124,255,.10);
}
.dashboard-page .dash-glance-car::after {
    width: 170px; height: 170px;
    border: 1px dashed rgba(39,215,255,.18);
}
.dashboard-page .dash-car-body {
    fill: #11182A;
    stroke: #6687FF;
    stroke-width: 2;
}
.dashboard-page .dash-car-glass { fill: rgba(39,215,255,.12); }
.dashboard-page .dash-car-roof {
    fill: #0A1020;
    stroke: rgba(139,165,255,.25);
}
.dashboard-page .dash-card {
    border-radius: 18px;
    border-color: rgba(112,143,255,.14);
    background: linear-gradient(145deg, rgba(17,24,42,.96), rgba(10,14,26,.96));
}
.carx-dvr-card { position: relative; overflow: hidden; }
.carx-dvr-card::before {
    content: "";
    position: absolute;
    width: 220px; height: 220px;
    right: -110px; top: -110px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(91,124,255,.18), transparent 68%);
    pointer-events: none;
}
.carx-dvr-status {
    display: flex;
    align-items: center;
    gap: 9px;
    margin: 4px 0 14px;
    color: var(--text-secondary);
    font-size: 13px;
    font-weight: 700;
}
.carx-dvr-dot {
    width: 9px; height: 9px;
    border-radius: 50%;
    background: #94A3B8;
    box-shadow: 0 0 0 5px rgba(148,163,184,.08);
}
.carx-dvr-status.is-enabled .carx-dvr-dot {
    background: #22C55E;
    box-shadow: 0 0 0 5px rgba(34,197,94,.10);
}
.carx-dvr-status.is-disabled .carx-dvr-dot {
    background: #F59E0B;
    box-shadow: 0 0 0 5px rgba(245,158,11,.10);
}
.carx-dvr-status.is-error .carx-dvr-dot {
    background: #EF4444;
    box-shadow: 0 0 0 5px rgba(239,68,68,.10);
}
.carx-dvr-actions {
    display: grid;
    grid-template-columns: minmax(0,1fr) minmax(0,1fr);
    gap: 10px;
}
.carx-dvr-actions .dash-primary-btn,
.carx-dvr-actions .dash-secondary-btn {
    width: 100%;
    min-height: 44px;
    border-radius: 12px;
}
@media (max-width: 560px) {
    .carx-dvr-actions { grid-template-columns: 1fr; }
}
'''
    path.write_text(content, encoding="utf-8")
    print("[CarX] created", path.relative_to(ROOT))

def create_carx_js():
    path = ROOT / "app/src/main/assets/web/shared/carx-sentry.js"
    content = '''/* CarX Sentry Mode dashboard helpers - ES5 / Chrome 58 compatible. */
(function () {
    'use strict';

    function t(key, fallback) {
        try {
            if (window.BYD && BYD.i18n && typeof BYD.i18n.t === 'function') {
                var v = BYD.i18n.t(key);
                if (v && v !== key) return v;
            }
        } catch (e) {}
        return fallback;
    }

    function toast(message, type) {
        try {
            if (window.BYD && BYD.utils && BYD.utils.toast) {
                BYD.utils.toast(message, type || 'info');
            }
        } catch (e) {}
    }

    var CarXNativeDvr = {
        state: 'unknown',
        busy: false,

        init: function () {
            var self = this;
            var button = document.getElementById('carxDvrToggle');
            if (button) button.onclick = function () { self.toggle(); };
            this.refresh();
            if (window.BYD && BYD.i18n && typeof BYD.i18n.onChange === 'function') {
                BYD.i18n.onChange(function () { self.render(self.state); });
            }
        },

        refresh: function () {
            var self = this;
            self.render('checking');
            fetch('/api/oem-dashcam/native-dvr/status', { cache: 'no-store' })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    var state = data && data.state ? data.state : 'unknown';
                    self.state = state;
                    self.render(state);
                })
                .catch(function () {
                    self.state = 'error';
                    self.render('error');
                });
        },

        toggle: function () {
            if (this.busy) return;
            if (this.state !== 'enabled' && this.state !== 'disabled') {
                this.refresh();
                return;
            }
            var self = this;
            self.busy = true;
            var endpoint = this.state === 'enabled'
                ? '/api/oem-dashcam/native-dvr/disable'
                : '/api/oem-dashcam/native-dvr/enable';
            var button = document.getElementById('carxDvrToggle');
            if (button) button.disabled = true;

            fetch(endpoint, { method: 'POST' })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (!data || data.success === false) {
                        throw new Error(data && (data.error || data.message) || 'DVR change failed');
                    }
                    toast(data.message || 'DVR state updated', 'success');
                    setTimeout(function () { self.refresh(); }, 350);
                })
                .catch(function () {
                    self.state = 'error';
                    self.render('error');
                    toast(t('carx.dvr_failed', 'Could not change DVR state'), 'error');
                })
                .then(function () {
                    self.busy = false;
                    if (button) button.disabled = false;
                });
        },

        render: function (state) {
            var box = document.getElementById('carxDvrStatus');
            var label = document.getElementById('carxDvrStatusText');
            var button = document.getElementById('carxDvrToggle');
            if (!box || !label || !button) return;

            box.className = 'carx-dvr-status';
            button.style.display = '';

            if (state === 'checking' || state === 'unknown') {
                label.textContent = t('carx.dvr_checking', 'Checking native DVR…');
                button.textContent = t('carx.dvr_disable', 'Disable Native DVR');
                button.disabled = true;
                return;
            }
            if (state === 'enabled') {
                box.className += ' is-enabled';
                label.textContent = t('carx.dvr_enabled', 'Native DVR enabled');
                button.textContent = t('carx.dvr_disable', 'Disable Native DVR');
                button.disabled = false;
                return;
            }
            if (state === 'disabled') {
                box.className += ' is-disabled';
                label.textContent = t('carx.dvr_disabled', 'Native DVR disabled');
                button.textContent = t('carx.dvr_restore', 'Restore Native DVR');
                button.disabled = false;
                return;
            }
            if (state === 'not_installed') {
                label.textContent = t('carx.dvr_not_installed', 'Native DVR is not installed on this vehicle');
                button.style.display = 'none';
                return;
            }
            box.className += ' is-error';
            label.textContent = t('carx.dvr_failed', 'Could not read DVR state');
            button.textContent = t('carx.dvr_disable', 'Disable Native DVR');
            button.disabled = false;
        }
    };

    window.CarXNativeDvr = CarXNativeDvr;

    function boot() { CarXNativeDvr.init(); }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
'''
    path.write_text(content, encoding="utf-8")
    print("[CarX] created", path.relative_to(ROOT))

def patch_dashboard():
    path = FILES["index"]
    text = path.read_text(encoding="utf-8")
    original = text

    text = text.replace(
        '<title data-i18n="app.dashboard_title">Dashboard - OverDrive</title>',
        '<title data-i18n="app.dashboard_title">CarX Sentry Mode</title>'
    )
    text = text.replace(
        '<div class="brand"><span class="brand-name" style="font-size:16px;">OverDrive</span></div>',
        '<div class="brand"><span class="brand-name" style="font-size:16px;">CarX Sentry Mode</span></div>'
    )
    text = text.replace(
        '<h1 data-i18n="dashboard.heading">Dashboard</h1>',
        '<h1 data-i18n="dashboard.heading">CarX Sentry Mode</h1>'
    )
    text = text.replace(
        '<p id="dashHeroSubtitle" data-i18n="dashboard.subtitle">Vehicle status, position and main controls.</p>',
        '<p id="dashHeroSubtitle" data-i18n="dashboard.subtitle">BYD sentry, cameras and security at a glance.</p>'
    )

    card_anchor = '<section class="dash-grid" id="dashCards">'
    if 'id="carxDvrStatus"' not in text:
        if card_anchor not in text:
            die("Dashboard grid marker not found.")
        carx_card = '''
                    <article class="dash-card carx-dvr-card" data-card-id="carx-dvr">
                        <div class="dash-card-head">
                            <div>
                                <span class="dash-card-kicker" data-i18n="carx.security_core">CarX Security Core</span>
                                <h2 data-i18n="carx.dvr_card_title">Native DVR Control</h2>
                            </div>
                        </div>
                        <p style="margin:-4px 0 12px;color:var(--text-muted);font-size:13px;line-height:1.5;"
                           data-i18n="carx.dvr_card_desc">Direct, reversible control of BYD's com.byd.cdr factory recorder.</p>
                        <div class="carx-dvr-status" id="carxDvrStatus">
                            <span class="carx-dvr-dot" aria-hidden="true"></span>
                            <span id="carxDvrStatusText" data-i18n="carx.dvr_checking">Checking native DVR…</span>
                        </div>
                        <div class="carx-dvr-actions">
                            <button class="dash-primary-btn" id="carxDvrToggle" type="button"
                                    data-i18n="carx.dvr_disable">Disable Native DVR</button>
                            <button class="dash-secondary-btn" type="button"
                                    onclick="location.href='surveillance.html'"
                                    data-i18n="carx.open_sentry">Open Sentry Settings</button>
                        </div>
                    </article>
'''
        text = text.replace(card_anchor, card_anchor + carx_card, 1)

    script_tag = '    <script src="../shared/carx-sentry.js?v=1"></script>\n'
    if 'carx-sentry.js' not in text:
        if '</body>' not in text:
            die("Dashboard </body> marker not found.")
        text = text.replace('</body>', script_tag + '</body>', 1)

    if text != original:
        write_text(path, text)
    else:
        print("[CarX] dashboard already patched")

def patch_shell():
    path = FILES["shell"]
    text = path.read_text(encoding="utf-8")
    original = text
    swaps = [
        ('aria-label="OverDrive — open Dashboard"', 'aria-label="CarX Sentry Mode — open Home"'),
        ('alt="OverDrive"', 'alt="CarX Sentry Mode"'),
        ('data-i18n="app.name">OverDrive</span>', 'data-i18n="app.name">CarX Sentry Mode</span>'),
        ('data-i18n="app.tagline">Surveillance System</span>', 'data-i18n="app.tagline">BYD Sentry Command Center</span>'),
    ]
    for old, new in swaps:
        text = text.replace(old, new)
    if text != original:
        write_text(path, text)
    else:
        print("[CarX] app shell already patched")

def main():
    require_files()
    BACKUP.mkdir(exist_ok=True)

    replace_once(
        FILES["settings"],
        'rootProject.name = "Overdrive"',
        'rootProject.name = "CarX Sentry Mode"'
    )

    strings = FILES["strings"].read_text(encoding="utf-8")
    new_strings = strings.replace(
        '<string name="app_name">OverDrive</string>',
        '<string name="app_name">CarX Sentry Mode</string>',
        1
    ).replace(
        '<string name="accessibility_service_description">Keeps Overdrive vehicle monitoring active in the background. This service does not read or interact with screen content.</string>',
        '<string name="accessibility_service_description">Keeps CarX Sentry Mode monitoring active in the background. This service does not read or interact with screen content.</string>',
        1
    )
    if new_strings != strings:
        write_text(FILES["strings"], new_strings)

    patch_json(FILES["en"], "en")
    patch_json(FILES["ar"], "ar")
    patch_shell()
    patch_dashboard()

    styles = FILES["styles"].read_text(encoding="utf-8")
    import_line = '@import url("carx-brand.css?v=1");'
    if import_line not in styles:
        marker = '@import url("app-collapse.css");'
        if marker not in styles:
            die("styles.css import marker not found.")
        styles = styles.replace(marker, marker + "\n" + import_line, 1)
        write_text(FILES["styles"], styles)

    create_carx_css()
    create_carx_js()

    notes = ROOT / "CARX_SENTRY_PATCH_INFO.txt"
    notes.write_text(
        "CarX Sentry Mode v1 patch applied.\n"
        "- Visible branding renamed to CarX Sentry Mode.\n"
        "- Arabic/English core sentry strings improved.\n"
        "- Futuristic lightweight dashboard styling added.\n"
        "- Direct BYD native DVR disable/restore card added using existing API.\n"
        "- applicationId/package remains com.overdrive.app in v1 for stability.\n"
        "- Camera/daemon/native pipeline code was NOT rewritten.\n"
        "- Upstream MIT LICENSE remains untouched.\n"
        "- Backups are stored in .carx_backup_v1/\n",
        encoding="utf-8"
    )
    print("\n[CarX] PATCH COMPLETE")
    print("[CarX] Next build command: ./gradlew assembleDebug")
    print("[CarX] APK path after success: app/build/outputs/apk/debug/app-debug.apk")

if __name__ == "__main__":
    main()
